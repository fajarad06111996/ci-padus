<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>
                   <b> INPUT DATA </b>
                    
                </h2>
            </div>
            <!-- Basic Examples -->
            <div class="row clearfix">
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <a href="<?php echo base_url('admin/data_rc'); ?>" type="button" class="btn bg-teal waves-effect"><i class="material-icons">reply</i> Kembali</a>
                            <ul class="header-dropdown m-r--5">
                                
                            </ul>
                        </div>
                        <div class="body">
                            <form>
                                <label>Pick Up Info</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" placeholder="Pick Up Info">
                                    </div>
                                </div>
								<label>Pick up date</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="Pick up date">
                                    </div>
                                </div>
								<label>Shipper Name</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="Shipper Name">
                                    </div>
                                </div>
								<label>AWB No</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="AWB No">
                                    </div>
                                </div>
								<label>Description</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="Description">
                                    </div>
                                </div>
								<label>Consignee</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="Consignee">
                                    </div>
                                </div>
								<label>Address</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="Address">
                                    </div>
                                </div>
								<label>Destination</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="Destination">
                                    </div>
                                </div>
								<label>Weight</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="Weight">
                                    </div>
                                </div>
								<label>Colly</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="Colly">
                                    </div>
                                </div>
								<label>Moda</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="Moda">
                                    </div>
                                </div>
								<label>TAT</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="TAT">
                                    </div>
                                </div>
								<label>ETA</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="date" name="" class="form-control" placeholder="ETA">
                                    </div>
                                </div>
								<label>Received By</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="Received By">
                                    </div>
                                </div>
								<label>ATA</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="ATA">
                                    </div>
                                </div>
								<label>Remarks</label>
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="" class="form-control" placeholder="Remarks">
                                    </div>
                                </div>
                                <button type="button" class="btn bg-purple waves-effect">
                                    <i class="material-icons">add_circle_outline</i> Tambah
                                </button>
                            </form>
                        </div>
                    </div>
                </div> 
            </div>
            <!-- #END# Basic Examples -->
            <!-- Exportable Table -->
            <!-- #END# Exportable Table -->
        </div>
    </section>